package laba2;

import java.io.*;
import java.util.Scanner;

public class lab2 
{
	public static void main(String[] str)
	{
		Scanner in = new Scanner(System.in);
		byte v=0;
		do 
		{
			System.out.println("[1]String");
			System.out.println("[2]File reader");
			System.out.println("[3]Input & output from text");
			System.out.println("[~]Exit");
			try
			{
				v=in.nextByte();
				switch(v)
				{
					case 1: one();break;
					default: System.out.println("There no such task!");
				}
			}	
			catch(Exception e) 
			{
				System.out.println("Error "+e.toString());
			}
		}
		while(v!=4);
	}
	
	public static void one()
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a text string - ");
		String s=in.nextLine();

		String[] sarr = s.split(" ");
        int count = 0;
        for(String str : sarr) 
        {
            try 
            {
            	Integer.parseInt(str);
            }
            catch(NumberFormatException e)
            {
            	count++;
            }
        }
        
        byte j=0;
		char []c=new char[s.length()];
		for(int i=s.length()-1;i>=0;i--)
		{
			c[j]=s.charAt(i);
			j++;
		}
		s=new String(c);
		
		System.out.println("Inverted text: "+s);
		System.out.print("The number of digits in the text: ");
		System.out.print(sarr.length - count);
		System.out.print("\n");
	}
}
